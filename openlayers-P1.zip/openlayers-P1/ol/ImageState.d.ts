declare namespace _default {
    const IDLE: number;
    const LOADING: number;
    const LOADED: number;
    const ERROR: number;
    const EMPTY: number;
}
export default _default;
//# sourceMappingURL=ImageState.d.ts.map