declare namespace _default {
    const CHANGE: string;
    const ERROR: string;
    const BLUR: string;
    const CLEAR: string;
    const CONTEXTMENU: string;
    const CLICK: string;
    const DBLCLICK: string;
    const DRAGENTER: string;
    const DRAGOVER: string;
    const DROP: string;
    const FOCUS: string;
    const KEYDOWN: string;
    const KEYPRESS: string;
    const LOAD: string;
    const RESIZE: string;
    const TOUCHMOVE: string;
    const WHEEL: string;
}
export default _default;
//# sourceMappingURL=EventType.d.ts.map