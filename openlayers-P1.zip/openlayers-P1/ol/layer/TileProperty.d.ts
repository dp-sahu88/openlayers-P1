declare namespace _default {
    const PRELOAD: string;
    const USE_INTERIM_TILES_ON_ERROR: string;
}
export default _default;
//# sourceMappingURL=TileProperty.d.ts.map