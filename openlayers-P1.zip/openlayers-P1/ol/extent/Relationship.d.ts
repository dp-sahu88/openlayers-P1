declare namespace _default {
    const UNKNOWN: number;
    const INTERSECTING: number;
    const ABOVE: number;
    const RIGHT: number;
    const BELOW: number;
    const LEFT: number;
}
export default _default;
//# sourceMappingURL=Relationship.d.ts.map