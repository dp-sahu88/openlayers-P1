
//crate a map////////////////////////////////////////////////////////////////////////////
const map = new ol.Map({ target: 'map' })

//layer 1////////////////////////////////////////////////////////////////////////////////
let OSMsource = new ol.source.OSM()
let layer1 = new ol.layer.Tile({
  title: 'Base layer',
  source: OSMsource
})
map.addLayer(layer1)

// layer 2//////////////////////////////////////////////////////////////////////////////
let populatedPlacesSource = new ol.source.Vector({
  url: 'resource/populated_places.json',
  format: new ol.format.GeoJSON()
})
let layer2 = new ol.layer.Vector({
  title: 'Most Populated places',
  source: populatedPlacesSource
})
map.addLayer(layer2)

// layer X //////////////////////////////////////////////////////////////////////////////
const sourceX = new ol.source.Vector();
console.log(sourceX)
const layerX = new ol.layer.Vector({
  source: sourceX
});
map.addLayer(layerX);

// function to set position
var setPosition = (pos) => {
  const coords = [pos.coords.longitude, pos.coords.latitude];
  const accuracy = ol.geom.Polygon.circular(coords, pos.coords.accuracy)  ;
  sourceX.clear(true);
  sourceX.addFeatures([
    new ol.Feature(
      accuracy.transform('EPSG:4326', map.getView().getProjection())
    ),
    new ol.Feature(new ol.geom.Point(ol.proj.fromLonLat(coords))),
  ]);
}
// function to handel error
var handelError = (error) => {
  alert(`ERROR: ${error.message}`);
}
// set options for watchPosition
var watchPositionOptions = {
  enableHighAccuracy: true,
}

// get and set the live location
navigator.geolocation.watchPosition(
  setPosition,
  handelError,
  watchPositionOptions
);

// locate me div
const locate = document.createElement('div');
locate.className = 'ol-control ol-unselectable locate';
locate.innerHTML = '<button title="Locate me">◎</button>';
locate.addEventListener('click', () => {
  if (!sourceX.isEmpty()) {
    map.getView().fit(sourceX.getExtent(), {
      maxZoom: 18,
      duration: 500,
    });
  }
});
map.addControl(
  new ol.control.Control({
    element: locate,
  })
);

//set the view ////////////////////////////////////////////////////////////////////
let view = new ol.View({
  center: [0, 0],
  zoom: 1
})
map.setView(view)
console.log(map);
// switchlayers //////////////////////////////////////////////////////////////////

const layerSwitcher = new LayerSwitcher({
  reverse: true,
  groupSelectStyle: "group"
});
map.addControl(layerSwitcher);



